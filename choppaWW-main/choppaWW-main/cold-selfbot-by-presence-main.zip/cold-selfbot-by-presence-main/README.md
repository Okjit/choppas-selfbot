# cold-selfbot-by-presence
discord selfbot made by me. presence#3333 on cord 
